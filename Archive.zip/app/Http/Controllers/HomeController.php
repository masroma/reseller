<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Collection;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $totalCart = Cart::where('ip_address','=',$request->ip())->count();
        $apiresponse = Http::get('http://localhost:8000/api/products');
        $data = $apiresponse->collect();
        return view('home',compact('data','totalCart'));
    }

    public function detail(Request $request, $slug)
    {
        $apiresponse = Http::get('http://localhost:8000/api/product/'.$slug);
        $data = $apiresponse->collect();
        $totalCart = Cart::where('ip_address','=',$request->ip())->count();
        return view('detail',compact('data','totalCart'));
    }


}
