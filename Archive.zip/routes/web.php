<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', 'HomeController@index')->name('homepage');
Route::get('detail-product/{slug}', 'HomeController@detail')->name('product-detail');
Route::get('keranjang-belanja', 'CartController@index')->name('keranjang-belanja');
Route::post('tambah-keranjang','CartController@store')->name('tambah-keranjang');
Route::post('update-keranjang','CartController@update')->name('update-keranjang');
Route::get('hapus-keranjang/{id}','CartController@destroy')->name('hapus-keranjang');
Route::get('checkout', 'CartController@checkout')->name('checkout');
Route::get('province', 'CartController@get_province')->name('province');
Route::get('kota/{id}', 'CartController@get_city')->name('kota');
Route::get('/origin={city_origin}&destination={city_destination}&weight={weight}&courier={courier}','CartController@get_ongkir');
Route::post('proses-transaksi','CartController@prosesTransaksi')->name('proses-transaksi');
Route::get('sukses-transaksi', 'CartController@suksesTransaksi')->name('sukses-transaksi');
Route::get('sendemail', 'CartController@sendEmail')->name('sendemail');
