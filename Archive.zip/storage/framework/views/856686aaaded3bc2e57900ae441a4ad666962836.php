<?php $__env->startSection("title"); ?> Detail Product <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row">
            <div class="col-md-5 mb-5">
                <img class="img-fluid w-100" src="<?php echo e($data['product']['image']); ?>" alt="<?php echo e($data['product']['slug']); ?>" />
            </div>
            <div class="col-md-7">
                <h2><?php echo e($data['product']['title']); ?></h2>
                <p>Kategori : <b><?php echo e($data['product']['category']['name']); ?></b> Berat : <b><?php echo e($data['product']['weight']); ?> gram</b></p>
                <h3>Rp. <?php echo e(number_format($data['product']['price'])); ?></h3>
                <p><?php echo $data['product']['content']; ?></p>

                <div class="row">
                    <div class="col mt-5">
                        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tambah-keranjang')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($data['product']['id']); ?>">
                        <input type="hidden" name="title" value="<?php echo e($data['product']['title']); ?>">
                        <input type="hidden" name="price" value="<?php echo e($data['product']['price']); ?>">
                        <input type="hidden" name="image" value="<?php echo e($data['product']['image']); ?>">
                        <input type="hidden" name="weight" value="<?php echo e($data['product']['weight']); ?>">
                        <label for="">QTY</label>
                        <input type="number" class="form-control mb-2" min="1" value="1" name="custom_qty" required>
                        <button href="" class="btn btn-dark btn-block">Beli Sekarang</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/reseller/resources/views/detail.blade.php ENDPATH**/ ?>