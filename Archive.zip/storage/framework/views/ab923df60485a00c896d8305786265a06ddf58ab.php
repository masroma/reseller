<?php $__env->startSection("title"); ?> Keranjang Belanja <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
        <div class="text-center text-white">
            <h1 class="display-4 fw-bolder">Keranjang Belanja</h1>
            <p class="lead fw-normal text-white-50 mb-0"></p>
        </div>
    </div>
</header>
<section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive-sm">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Nama Produk</th>
                        <th scope="col">Qty</th>
                        <th scope="col">Sub Price</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $total = 0; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total = $total + ($row->price * $row->qty);?>
                    <tr>
                        <th scope="row"><?php echo e($index+1); ?></th>
                        <td><img src="<?php echo e($row->image); ?>" width="120px" alt="<?php echo e($row->title); ?>"></td>
                        <td><?php echo e($row->title); ?></td>
                        <td>
                            <form class="form-inline flex" action="<?php echo e(route('update-keranjang')); ?>" method="post" >
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="hidden" name="product_id" value="<?php echo e($row->product_id); ?>">
                                    <input type="number" style="width:60px" value="<?php echo e($row->qty); ?>" name="custom_qty" min="1">
                                    <button class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></button>
                                </div>
                            </form>
                        </td>
                        <td>Rp <?php echo e(number_format($row->price * $row->qty)); ?> </td>
                        <td>

                            <a href="<?php echo e(route('hapus-keranjang',$row->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="4" align="center"><b>Total Belanja</b></td>
                        <td colspan="2" align="center">Rp <b><?php echo e(number_format($total)); ?></b></td>
                    </tr>
                    <tr>
                        <td colspan="4" align="center"></td>
                        <td colspan="2" align="center">
                            <a href="<?php echo e(route('homepage')); ?>" class="btn btn-warning btn-sm">Lanjut Belanja</a>
                            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success btn-sm">Checkout</a>
                        </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/reseller/resources/views/keranjang.blade.php ENDPATH**/ ?>